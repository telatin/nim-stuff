#!/bin/bash
set -exuo pipefail
OLDWD=$PWD

PLATFORM=$(uname)
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null && pwd )"


nim --version >/dev/null 2>&1       || { echo "nim compiler not found."; exit 1; }

RELEASE=""
if [ "${NIM_RELEASE+x}" ]; then
 RELEASE=" -d:release ";
fi

nim c -w:on  --opt:speed $RELEASE -p:$DIR/../lib -o:bin/seqfu_$(uname) $DIR/main.nim || { echo "Compilation failed."; exit 1; }

if [ -e "$DIR/test/mini.sh" ];
  bash $DIR/test/mini.sh
else
  echo "test/mini.sh NOT found: skipping"
fi

VERSION=$(grep return pkg_utils.nim | grep -o \\d\[^\"\]\\+ | head -n 1)
echo "Version: $VERSION"
